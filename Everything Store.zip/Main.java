/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

import menu.MenuApp;
import web.WebApp;

import java.io.IOException;
import java.sql.SQLException;
class Main {
  public static void main(String[] args)  throws IOException, SQLException {
    
   //To separate call the web server and the console menu
    
       WebApp.start();
       MenuApp.start();
  }
}
 