/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package dao;

import model.Address;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

//Dao class is in charge of handling database processing.

public class AddressDao {
  //Execution point
  public AddressDao() {
  }

  private static Connection getDBConnection() {
    Connection dbConnection = null;
    try {
      Class.forName("org.sqlite.JDBC");
    } catch (ClassNotFoundException e) {
      System.out.println(e.getMessage());
    }
    try {
      String dbURL = "jdbc:sqlite:everythingstore.db";
      dbConnection = DriverManager.getConnection(dbURL);
      return dbConnection;
    } catch (SQLException e) {
      System.out.println(e.getMessage());
    }
    return dbConnection;
  }
               //To get address 
public Address getAddress(int addressId) throws SQLException {

    Address temp = null;
    Connection dbConnection = null;
    Statement statement = null;
    ResultSet result = null;

    String query = "SELECT * FROM address WHERE AddressId =" + addressId + ";";  

    try {
      dbConnection = getDBConnection();
      statement = dbConnection.createStatement();
      System.out.println("DBQuery: " + query);
      result = statement.executeQuery(query); //Execute SQL query

      while (result.next()) {
        String house = result.getString("house");
        String addressLine1 = result.getString("addressLine1");
        String addressLine2 = result.getString("addressLine2");
        String postCode = result.getString("postCode");
        String country = result.getString("country");
        
        temp = new Address(addressId, house, addressLine1, addressLine2, country,postCode);

  }
    } finally {
      if (result != null) {
        result.close();
      }
      if (statement != null) {
        statement.close();
      }
      if (dbConnection != null) {
        dbConnection.close();
      }
    }
    return temp;
  }
               
                 //To delete a address       
public Boolean deleteAddress(int addressId) throws SQLException {
    System.out.println("Deleting address");
    Connection dbConnection = null;
    Statement statement = null;
    int result = 0;
    String query = "DELETE FROM address WHERE AddressId = " + addressId + ";";
    try {
      dbConnection = getDBConnection();
      statement = dbConnection.createStatement();
      System.out.println(query);
      result = statement.executeUpdate(query);
    } finally {
      if (statement != null) {
        statement.close();
      }
      if (dbConnection != null) {
        dbConnection.close();
      }
    }
    if (result == 1) {
      return true;
    } else {
      return false;
    }
  }   
       //To update the details of a product    
  public Boolean updateAddress(Address address) throws SQLException {
    Connection dbConnection = null;
    Statement statement = null;

    String query = "UPDATE address " + " Set House = '"
        + address.getHouse() +"', AddressLine1 = '"
        + address.getAddressLine1() + "'," + "AddressLine2= '" + 
          address.getAddressLine2() + "'," + "Country= '"
        + address.getCountry() + "', PostCode='" + address.getPostCode() + "' WHERE AddressId = "
        + address.getAddressId() + ";";

    try {
      dbConnection = getDBConnection();
      statement = dbConnection.createStatement();
      System.out.println(query);
      statement.executeUpdate(query);

    } catch (SQLException e) {

      System.out.println(e.getMessage());
      return false;

    } finally {

      if (statement != null) {
        statement.close();
      }
      if (dbConnection != null) {
        dbConnection.close();
      }
    }
    return true;
  }
          //To add a new product
  public Address addAddress(Address in) throws SQLException {
    int idGen=0;
    System.out.println("Start Add address DAO");
    Connection dbConnection = null;
    Statement statement = null;
    String update = "INSERT INTO address (House, AddressLine1, AddressLine2, Country,PostCode)" +
            "VALUES ('"
        + in.getHouse() + "','"
        + in.getAddressLine1() +
        "','" + in.getAddressLine2() +
        "','" + in.getCountry() + "','" +
        in.getPostCode() + "');";
    boolean ok = false;
    try {
      dbConnection = getDBConnection();
      statement = dbConnection.createStatement();
      System.out.println(update);
      statement.executeUpdate(update);
      ResultSet rs=statement.getGeneratedKeys(); 
       
   //Automatically generated key value.
       
      if(rs.next()) {
        idGen=rs.getInt(1);
      }
        ok = true;
    } catch (SQLException e) {
      System.out.println(e.getMessage());
    } finally {
      if (statement != null) {
        statement.close();
      }
      if (dbConnection != null) {
        dbConnection.close();
      }

    }
    System.out.println("idGen" + idGen);
    return new Address(idGen,
            in.getHouse(),
            in.getAddressLine1(),
            in.getAddressLine2(),
            in.getCountry(),in.getPostCode());

  }
}
