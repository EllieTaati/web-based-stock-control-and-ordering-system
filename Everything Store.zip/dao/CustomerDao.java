/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package dao;

import model.Address;
import model.Customer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
 
 // Dao class is in charge of handling database processing.
  
public class CustomerDao {
 //Execution point
  public CustomerDao() {
  }
  private static Connection getDBConnection() {
    Connection dbConnection = null;
    try {
      Class.forName("org.sqlite.JDBC");
    } catch (ClassNotFoundException e) {
      System.out.println(e.getMessage());
    }
    try {
      String dbURL = "jdbc:sqlite:everythingstore.db";
      dbConnection = DriverManager.getConnection(dbURL);
      return dbConnection;
    } catch (SQLException e) {
      System.out.println(e.getMessage());
    }
    return dbConnection;
  }
//A dynamic array
  public ArrayList<Customer> getAllCustomer() throws SQLException {
    System.out.println("Retrieving all Customers ...");
    Connection dbConnection = null;
    Statement statement = null;
    ResultSet result = null;
    String query = "SELECT * FROM Customer;";
    ArrayList<Customer> customers = new ArrayList<>();

    try {
      dbConnection = getDBConnection();
      statement = dbConnection.createStatement();
      System.out.println("DBQuery = " + query);
      result = statement.executeQuery(query);
      while (result.next()) {

        int customerID = result.getInt("CustomerID");
        String firstName = result.getString("FirstName");
        String secondName = result.getString("SecondName");
        int addressId = result.getInt("AddressId");
        AddressDao addressDao = new AddressDao();
        Address address =addressDao.getAddress(addressId);
        String telephoneNumber = result.getString("TelephoneNumber");
        customers.add(new Customer(customerID, firstName, secondName, address, telephoneNumber));
      }
    } catch (Exception e) {
      System.out.println("get all customers: " + e);
    } finally {
      if (result != null) {
        result.close();
      }
      if (statement != null) {
        statement.close();
      }
      if (dbConnection != null) {
        dbConnection.close();
      }
    }
    return customers;
  }
          //To get customer
  public Customer getCustomer(int customer_id) throws SQLException {

    Customer temp = null;
    Connection dbConnection = null;
    Statement statement = null;
    ResultSet result = null;

    String query = "SELECT * FROM customer WHERE CustomerID =" + customer_id + ";";

    try {
      dbConnection = getDBConnection();
      statement = dbConnection.createStatement();
      System.out.println("DBQuery: " + query);

      result = statement.executeQuery(query);

      while (result.next()) {

        int customerID = result.getInt("CustomerID");
        String firstName = result.getString("FirstName");
        String secondName = result.getString("SecondName");
        //To get address from address table
        int addressId = result.getInt("AddressId");
        AddressDao addressDao = new AddressDao();
        Address address =addressDao.getAddress(addressId);
        String telephoneNumber = result.getString("TelephoneNumber");
        temp = new Customer(customerID, firstName, secondName, address, telephoneNumber);

      }
    } finally {
      if (result != null) {
        result.close();
      }
      if (statement != null) {
        statement.close();
      }
      if (dbConnection != null) {
        dbConnection.close();
      }
    }
    return temp;
  }
                 //To delete a customer
  public Boolean deleteCustomer(int customer_id) throws SQLException {
    System.out.println("Deleting customer");
    Connection dbConnection = null;
    Statement statement = null;
    int result = 0;
    String query = "DELETE FROM customer WHERE CustomerID = " + customer_id + ";";
    try {
      dbConnection = getDBConnection();
      statement = dbConnection.createStatement();
      System.out.println(query);
      result = statement.executeUpdate(query);
    } finally {
      if (statement != null) {
        statement.close();
      }
      if (dbConnection != null) {
        dbConnection.close();
      }
    }
    if (result == 1) {
      return true;
    } else {
      return false;
    }
  }
   
     //To update the details of a customer 
  public Boolean updatecustomer(Customer customer) throws SQLException {
    Connection dbConnection = null;
    Statement statement = null;

    String query = "UPDATE customer " + "SET FirstName = '"
            + customer.getFirstName() + "',"
            + "SecondName= '" + customer.getSecondName()
            + "'," + "TelephoneNumber='" + customer.getTelephoneNumber()
            + "' WHERE CustomerID = "
        + customer.getCustomerID() + ";";

    try {
      dbConnection = getDBConnection();
      statement = dbConnection.createStatement();
      System.out.println(query);
      statement.executeUpdate(query);

    } catch (SQLException e) {

      System.out.println(e.getMessage());
      return false;

    } finally {

      if (statement != null) {
        statement.close();
      }
      if (dbConnection != null) {
        dbConnection.close();
      }
    }
    return true;
  }
           
        //To add a new customer
  
  public boolean addCustomer(Customer in) throws SQLException {
    Connection dbConnection = null;
    Statement statement = null;

    String addQuery = "INSERT INTO customer (FirstName, SecondName, AddressId, TelephoneNumber) " +
            "VALUES ('"+ in.getFirstName() +
            "','" + in.getSecondName() +
            "','" + in.getAddressId().getAddressId() +
            "'," + in.getTelephoneNumber() + ");";

    boolean ok = false;
    try {
      dbConnection = getDBConnection();
      statement = dbConnection.createStatement();
      System.out.println(addQuery);
      statement.executeUpdate(addQuery);
      ok = true;
    } catch (SQLException e) {
      System.out.println(e.getMessage());
    } finally {
      if (statement != null) {
        statement.close();
      }
      if (dbConnection != null) {
        dbConnection.close();
      }

    }
    return ok;

  }
  
  
}
