/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package dao;

import model.Product;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
  //Dao class is in charge of handling database processing.
  
public class ProductDao {  
	public ProductDao() {}
	
	private static Connection getDBConnection() {
		Connection dbConnection = null;
		try {
			Class.forName("org.sqlite.JDBC");
			} catch (ClassNotFoundException e) {
				System.out.println(e.getMessage());
			}
		try {
			String dbURL = "jdbc:sqlite:everythingstore.db";
			dbConnection = DriverManager.getConnection(dbURL);
			return dbConnection;
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
		return dbConnection;
		}	
       //A dynamic array       
	public ArrayList<Product> getAllProducts() throws SQLException {
		System.out.println("Retrieving all Products ...");
		Connection dbConnection = null;
		Statement statement = null;
		ResultSet result = null;
    //To retrieve a product record from the database.
		String query = "SELECT * FROM Product;";
		ArrayList<Product> products = new ArrayList<>();

		try {
			dbConnection = getDBConnection();
			statement = dbConnection.createStatement();
			System.out.println("DBQuery = " + query);
			result = statement.executeQuery(query); 
			while (result.next()) {
				int id = result.getInt("ID");
				String sku = result.getString("SKU");
				String description = result.getString("Description");
				String category = result.getString("Category");
				int price = result.getInt("Price");
				products.add(new Product(id,sku,description,category,price));
			}
		} catch(Exception e) {
			System.out.println("get all products: "+e);
		} finally {
			if (result != null) {
				result.close();
			}
			if (statement != null) {
				statement.close();
			}
			if (dbConnection != null) {
				dbConnection.close();
      }
    }
    return products;
  }
               
               //To get product               
	public Product getProduct(int product_ID) throws SQLException {

		Product temp = null;
		Connection dbConnection = null;
		Statement statement = null;
		ResultSet result = null;

		String query = "SELECT * FROM product WHERE ID =" + product_ID + ";";

		try {
			dbConnection = getDBConnection();
			statement = dbConnection.createStatement();
			System.out.println("DBQuery: " + query);
      			
			
			result = statement.executeQuery(query);
              System.out.print("result"+ result);
			while (result.next()) {
				int id = result.getInt("ID");
				String sku = result.getString("SKU");
				String description = result.getString("Description");
				String category = result.getString("Category");
				int price = result.getInt("Price");
				temp = new Product(id,sku,description,category,price);

			}
		} finally {
			if (result != null) {
				result.close();
			}
			if (statement != null) {
				statement.close();
			}
			if (dbConnection != null) {
				dbConnection.close();
			}
		}
		return temp;
  }
	          
                // To delete a prodct                
	public Boolean deleteProduct(int product_ID) throws SQLException {
		System.out.println("Deleting product");
		Connection dbConnection = null;
		Statement statement = null;
		int result = 0;
		String query = "DELETE FROM product WHERE ID = " + product_ID + ";";
		try {
			dbConnection = getDBConnection();
			statement = dbConnection.createStatement();
			System.out.println(query);
			result = statement.executeUpdate(query);
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (dbConnection != null) {
				dbConnection.close();
			}
		}
		if (result == 1) {
			return true;
		} else {
			return false;
		}
	}
      
       //To update the details of a product       
	public Boolean updateProduct(Product product) throws SQLException {
		Connection dbConnection = null;
		Statement statement = null;

		String query = "UPDATE product " +
				"Set SKU = '" +
				product.getSKU() +
				"'," + "Description= '" + product.getDescription() + "'," +
				"Category= '" + product.getCategory() + "'," +
				"Price= '" + product.getPrice() +
				"' WHERE ID = " + product.getID()
				+ ";";

		try {
			dbConnection = getDBConnection();
			statement = dbConnection.createStatement();
			System.out.println(query);
			statement.executeUpdate(query);

		} catch (SQLException e) {

			System.out.println(e.getMessage());
			return false;

		} finally {

			if (statement != null) {
				statement.close();
			}
			if (dbConnection != null) {
				dbConnection.close();
			}
		}
		return true;
	}
           
          //To add a new product           
	public boolean addProduct(Product in) throws SQLException{
		Connection dbConnection = null;
		Statement statement = null;
		
		String update = "INSERT INTO product (SKU, Description, Category, price) VALUES ('"+in.getSKU()+"','"+in.getDescription()+"','"+in.getCategory()+ "',"+in.getPrice()+");";
    
		boolean ok = false;
			try {
					dbConnection = getDBConnection();
					statement = dbConnection.createStatement();
					System.out.println(update);
					statement.executeUpdate(update);
					ok = true;
				} catch (SQLException e) {
					System.out.println(e.getMessage());
				} finally {
					if (statement != null) {
						statement.close();
					}
					if (dbConnection != null) {
						dbConnection.close();
					}
					
				}
			return ok;
  
	}
  
        
         //To search a product by description       
	public ArrayList<Product> searchByDescription(String keyword) throws SQLException {
		System.out.println("Search By Description ...");
		Connection dbConnection = null;
		Statement statement = null;
		ResultSet result = null;
		String query = "SELECT * FROM product WHERE Description LIKE '%"+keyword+"%'";
		ArrayList<Product> products = new ArrayList<>();

		try {
			dbConnection = getDBConnection();
			statement = dbConnection.createStatement();
			System.out.println("DBQuery = " + query);
			result = statement.executeQuery(query);
			while (result.next()) {
				int id = result.getInt("ID");
				String sku = result.getString("SKU");
				String description = result.getString("Description");
				String category = result.getString("Category");
				int price = result.getInt("Price");
				products.add(new Product(id,sku,description,category,price));
			}
		} catch(Exception e) {
			System.out.println("get search description: "+e);
		} finally {
			if (result != null) {
				result.close();
			}
			if (statement != null) {
				statement.close();
			}
			if (dbConnection != null) {
				dbConnection.close();
			}
		}
		return products;
	}

	}
