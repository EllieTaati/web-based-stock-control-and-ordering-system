/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package dao;

import model.Address;
import model.Customer;
import model.Product;
import java.sql.*;
import java.util.ArrayList;

public class UserDao {

    private static Connection getDBConnection() {
        Connection dbConnection = null;
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }
        try {
            String dbURL = "jdbc:sqlite:everythingstore.db";
            dbConnection = DriverManager.getConnection(dbURL);
            return dbConnection;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return dbConnection;
    }
    //To possible values for login 
    public boolean login(String username, String password) throws SQLException {

        boolean res = false;
        Connection dbConnection = null;
        Statement statement = null;
        ResultSet result = null;
        System.out.println("start to login DAO");
        String query = "SELECT * FROM user_ WHERE username ='" + username + "' and password='"+ password+"';";

        try {
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            System.out.println("DBQuery: " + query);
            result = statement.executeQuery(query);
             res= result.next();


            System.out.println("result of login is:"+ res);
        } finally {
            if (result != null) {
                result.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return res;
    }
      
    public boolean register(String username, String password) throws SQLException {
        Connection dbConnection = null;
        Statement statement = null;
        System.out.println("start to userDao registration!");
        String addQuery = "INSERT INTO user_ (username, password) VALUES ('"
           + username+ "','" + password +"');";
      
        boolean ok = false;
        try {
            dbConnection = getDBConnection();
            statement = dbConnection.createStatement();
            System.out.println(addQuery);
            statement.executeUpdate(addQuery);
            ok = true;
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            if (statement != null) {
                statement.close();
            }
            if (dbConnection != null) {
                dbConnection.close();
            }
        }
        return ok;

    }
}
