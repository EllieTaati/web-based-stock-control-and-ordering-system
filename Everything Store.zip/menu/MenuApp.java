/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package menu;

import dao.AddressDao;
import dao.ProductDao;
import model.Address;
import model.Product;
import dao.CustomerDao;
import model.Customer;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

  // To Create a console-based menu

public class MenuApp {
           
           //To declare multiple exceptions  
    public static void start() throws IOException, SQLException {
      //To receive input from the keyboard.      
        Scanner in = new Scanner(System.in); 
      
        ProductDao products = new ProductDao();
        CustomerDao customers = new CustomerDao();
        String selection ;

        do {
            System.out.println("--------------------");
            System.out.println("The Everything Store");
            System.out.println("Choose from these options");
            System.out.println("--------------------");

            System.out.println("[1] List all Products");
            System.out.println("[2] Search Product by ID");
            System.out.println("[3] Add a new Product");
            System.out.println("[4] Update a Product by ID");
            System.out.println("[5] Delete a Product by ID");
            System.out.println("[6] List all Customers");
            System.out.println("[7] Search Customer by ID");
            System.out.println("[8] Add a new Customer");
            System.out.println("[9] Update a Customer by ID");
            System.out.println("[10] Delete a Customer by ID");
            System.out.println("[11] Exit");
            System.out.println();

            selection = in.nextLine();

            switch (selection) {
                case "1":
                 //Code to list all products
                    ArrayList<Product> allProducts = products.getAllProducts();
                    for (int i = 0; i < allProducts.size(); i++){
                        System.out.println(allProducts.get(i));
                    }
                    System.out.println();
               
                    break;

                case "2":
                 //code to search a product by Id
                    System.out.println("\nEnter Product ID to get details  ");
                    int ID = Integer.parseInt(in.nextLine());
                    System.out.println(products.getProduct(ID).toString());
                    System.out.println();
                
                    break;

                case "3":
                 //Code to add a new product
                    System.out.println("Add a new Product");
                    Product product = createProduct();
                    products.addProduct(product);
                    System.out.println();
             
                    break;

                case "4":
                 //Code to update a product via ID
                    System.out.println("Update a Product");

                    System.out.println("\nEnter Product ID to update ");
                    int uID = Integer.parseInt(in.nextLine());
                    System.out.println(products.getProduct(uID));
                    Product updatedProduct =
                            updateProduct(products.getProduct(uID));
                    products.updateProduct(updatedProduct);
               
                    break;

                case "5":
                //Code to delete a product by ID
                    System.out.println("Delete Product");
                    System.out.println("Enter ID of Product to delete");
                    int dID = Integer.parseInt(in.nextLine());
                    products.deleteProduct(dID);
                
                    break;

                case "6":
                //Code to list all customers
                    ArrayList<Customer> allCustomers =
                            customers.getAllCustomer();
                    for (int i = 0; i < allCustomers.size(); i++){
                        System.out.println(allCustomers.get(i));
                    }
                    System.out.println();
                
                    break;

                case "7":
                //Code to search the customer details by Id
                    System.out.println("\nEnter Customer ID to get details  ");
                    int customerID = Integer.parseInt(in.nextLine());
                    System.out.println(customers.getCustomer(customerID));
                    System.out.println();
          
                    break;

                case "8":
                //Code to add a new customer
                    System.out.println("Add a new Customer");
                    Customer customer = createCustomer();
                    customers.addCustomer(customer);
                    System.out.println();
                
                    break;
                
                case "9":
                 //Code to update a customer details via ID
                    System.out.println("Update a Customer");
                    System.out.println("\nEnter Customer ID to update ");
                    int uCustomerId = 
                   Integer.parseInt(in.nextLine());
                    Customer uCustomer = 
      updateCustomer(customers.getCustomer(uCustomerId));
                    customers.updatecustomer(uCustomer);
                    System.out.println();
               
                    break;

                case "10":
                 //Code to delete a customer by ID
                    System.out.println("Delete a Customer By ID");
                    System.out.println("Enter ID of Customer to delete");
                    int customerId = Integer.parseInt(in.nextLine());
                    customers.deleteCustomer(customerId);
                    System.out.println();
               
                    break;

                case "11":
                    System.out.println("Exiting");
                    break;
                default:
                    System.out.println("Invalid Selection");
            }
        } while (!selection.equals("11"));

    }

    private static Product createProduct() {
      
        int id;
        String SKU;
        String description;
        String category;
        int price;

        Scanner in = new Scanner(System.in);
        System.out.println("Please enter SKU");
        SKU = in.nextLine();

        System.out.println("Please enter Description");
        description = in.nextLine();

        System.out.println("Please enter Category");
        category = in.nextLine();
        ;

        System.out.println("Please enter Price");
        price = Integer.parseInt(in.nextLine());
      /**
      *@return the new product details
      */
        return new Product(SKU, description, category, price);
    }
    private static Product updateProduct(Product product) {
        
        String SKU;
        String description;
        String category;
        int price;

        Scanner in = new Scanner(System.in);
        System.out.println("Updating Product with ID:" + product.getID());
        System.out.println("Please enter SKU");
        SKU = in.nextLine();
        if (SKU.equals(""))
            SKU = product.getSKU();

        System.out.println("Please enter new Description");
        description = in.nextLine();
        if (description.equals(""))
            description = product.getDescription();

        System.out.println("Please enter Category");
        category = in.nextLine();
        if (category.equals(""))
            category = product.getCategory();
      
        System.out.println("Please enter Price");
        String strPrice = in.nextLine();
        if (strPrice.equals(""))
            price = product.getPrice();
        else
            price = Integer.parseInt(strPrice);
      /**
      *@return the new details of the product 
      */
        return new Product(product.getID(), SKU, description, category, price);
    }

    private static Customer createCustomer() throws SQLException {
        
        AddressDao addressDao = new AddressDao();
        String firstName;
        String secondName;
        String telephoneNumber;

        Scanner in = new Scanner(System.in);

        System.out.println("Please enter FirstName");
        firstName = in.nextLine();

        System.out.println("Please enter SecondName");
        secondName = in.nextLine();

        System.out.println("Please enter TelephoneNumber");
        telephoneNumber = in.nextLine();

        System.out.println("Please enter Address");
        Address address = createCustomerAddress();
        address=addressDao.addAddress(address);
      /**
      *@return the new customer details
      */ 
        return new Customer(firstName,secondName,address,telephoneNumber);
    }

    private static Customer updateCustomer(Customer customer) throws SQLException {
        
        AddressDao addressDao = new AddressDao();
        String firstName;
        String secondName;
        String telephoneNumber;

        Scanner in = new Scanner(System.in);
        System.out.println("Updating Customer with ID:" + customer.getCustomerID());

        System.out.println("Please enter first name");
        firstName = in.nextLine();
        if (firstName.equals(""))
            firstName = customer.getFirstName();

        System.out.println("Please enter second name");
        secondName = in.nextLine();
        if (secondName.equals(""))
            secondName = customer.getSecondName();

        System.out.println("Please enter telephone number");
        telephoneNumber = in.nextLine();
        if (telephoneNumber.equals(""))
            telephoneNumber = customer.getTelephoneNumber();
        Address address= updateAddress(customer.getAddressId());
        addressDao.updateAddress(address);
      /**
      *@return the new details of the customer
      */
        return new Customer(customer.getCustomerID(), firstName,secondName,address,telephoneNumber);
    }

    private static Address updateAddress(Address address) {
        String house;
        String addressLine1;
        String addressLine2;
        String postCode;
        String country;

        Scanner in = new Scanner(System.in);

        System.out.println("Please enter house");
        house = in.nextLine();
        if (house.equals(""))
            house = address.getHouse();

        System.out.println("Please enter addressLine1");
        addressLine1 = in.nextLine();
        if (addressLine1.equals(""))
            addressLine1 = address.getAddressLine1();

        System.out.println("Please enter addressLine2");
        addressLine2 = in.nextLine();
        if (addressLine2.equals(""))
            addressLine2 = address.getAddressLine2();

        System.out.println("Please enter post code");
        postCode = in.nextLine();
        if (postCode.equals(""))
            postCode = address.getPostCode();

        System.out.println("Please enter country");
        country = in.nextLine();
        if (country.equals(""))
            country = address.getCountry();

        return new Address(address.getAddressId(),house,addressLine1,addressLine2,country,postCode);
    }

    private static Address createCustomerAddress() {

        String house;
        String addressLine1;
        String addressLine2;
        String country;
        String postCode;

        Scanner in = new Scanner(System.in);

        System.out.println("Please enter house");
        house = in.nextLine();

        System.out.println("Please enter addressLine1");
        addressLine1 = in.nextLine();

        System.out.println("Please enter addressLine2");
        addressLine2 = in.nextLine();

        System.out.println("Please enter country");
        country = in.nextLine();

        System.out.println("Please enter postCode");
        postCode = in.nextLine();
      /**
      *@return the new address of the customer 
      */
        return new Address(house,addressLine1,addressLine2,country,postCode);
    }
}