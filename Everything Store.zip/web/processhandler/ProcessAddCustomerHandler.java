/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package web.processhandler;

import java.io.OutputStreamWriter;

import dao.AddressDao;
import dao.CustomerDao;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import model.Address;
import model.Customer;
import web.util.Util;

import java.sql.SQLException;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.Map;
     
    //To give request and generate response 
public class ProcessAddCustomerHandler implements HttpHandler{

    public void handle(HttpExchange he) throws IOException {
         //To send the response
        System.out.println("ProcessAddCustomer Called");
        he.sendResponseHeaders(200,0);

        BufferedWriter out = new BufferedWriter(
                new OutputStreamWriter(he.getResponseBody() ));


        Map <String,String> parms = Util.requestStringToMap
                (he.getRequestURI().getQuery());
        System.out.println(parms);


        CustomerDao customers = new CustomerDao();
        AddressDao addressDao = new AddressDao();
        System.out.println("about to get data");


        String firstName = parms.get("firstName");
        String secondName = parms.get("secondName");
        String telephoneNumber = parms.get("telephoneNumber");
        System.out.println("about to create customer");

        String house = parms.get("house");
        String addressLine1 = parms.get("addressLine1");
        String addressLine2 = parms.get("addressLine2");
        String country = parms.get("country");
        String postCode = parms.get("postCode");

        try {
            Address address = new Address(house,addressLine1,addressLine2,country,postCode);
            address=addressDao.addAddress(address);
            Customer customer = new Customer(firstName,secondName,address,telephoneNumber);
            customers.addCustomer(customer);

            out.write(
                    "<html>" +
              "<head> <title>Customer Library</title> "+
                            "<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css\" integrity=\"sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2\" crossorigin=\"anonymous\">" +
                            "</head>" +
                            "<body style=background-color:#C3FDB8;>" +
               "<h1 style=color:darkgreen;font-family:Luminari;> Customer Added</h1>"+
                            "<table class=\"table\" style=background-color:white;border:solid;border-color:MediumSeaGreen;>" +
                            "<thead>" +
                            "  <tr>" +
                        
                            "    <th>FirstName</th>" +
                            "    <th>SecondName</th>" +
                            "    <th>Address</th>" +
                            "    <th>TelephoneNumber</th>" +

                            "  </tr>" +
                            "</thead>" +
                            "<tbody>");


            out.write(
                    "  <tr>"       +
                            
                            "    <td>"+ customer.getFirstName() + "</td>" +
                            "    <td>"+ customer.getSecondName() + "</td>" +
                            "    <td>"+ customer.getAddressId().toString() + "</td>" +
                            "    <td>"+ customer.getTelephoneNumber() + "</td>" +
                            "  </tr>"
            );

            out.write(
                    "</tbody>" +
                            "</table>" +
                            "<a href=\"/rootHandler?auth=true\">Back to List </a>"+
                            "</body>" +
                            "</html>");
        }catch(SQLException se){
            System.out.println(se.getMessage());
        }

        out.close();

    }


}


