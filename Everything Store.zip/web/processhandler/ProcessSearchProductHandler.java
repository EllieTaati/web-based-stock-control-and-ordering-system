/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package web.processhandler;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import dao.ProductDao;
import model.Product;
import web.util.Util;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

       //To give request and generate response 
public class ProcessSearchProductHandler implements HttpHandler {
    public void handle(HttpExchange he) throws IOException {
     //To send the response
        System.out.println("Process Search Product Called");
        he.sendResponseHeaders(200, 0);
        BufferedWriter out = new BufferedWriter(
                new OutputStreamWriter(he.getResponseBody()));


        Map<String, String> params = Util.requestStringToMap
                (he.getRequestURI().getQuery());

        System.out.println(params);

        try {
            System.out.println("about to get data");
            String keyword = params.get("searchDescription");
            ProductDao productDao = new ProductDao();
            List<Product> products = productDao.searchByDescription(keyword);
            out.write(

                    "<html>" +
                "<head> <title>Product Library</title> "+
                            "<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css\" integrity=\"sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2\" crossorigin=\"anonymous\">" +
                            "</head>" +
                           "<body style=background-color:#C3FDB8;>" +
                            "<div class=\"container\">" +
            "<h1 style=color:darkgreen;font-family:Luminari;> Products List!</h1>"+
                           "<table class=\"table\" style=background-color:white;border:solid;border-color:MediumSeaGreen;>" +
                            "<thead>" +
                            "  <tr>" +
                            "    <th>ID</th>" +
                            "    <th>SKU</th>" +
                            "    <th>Description</th>" +
                            "    <th>Category</th>" +
                            "    <th>Price</th>" +
                            "  </tr>" +
                            "</thead>" +
                            "<tbody>");

            for (Product p : products){
                out.write(
                        "  <tr>"       +
                "    <td>"+ p.getID() + "</td>" +
                "    <td>"+ p.getSKU() + "</td>" +
                "    <td>"+ p.getDescription() + "</td>" +
                "    <td>"+ p.getCategory() + "</td>" +
                "    <td>"+ p.getPrice() + "</td>" +
               "  </tr>"
                );
            }
            out.write(
                    "</tbody>" +
                            "</table>" +
   "<a href=\"/rootHandler?auth=true\">Back to List </a>"+
                            "</div>" +

                            "</body>" +
                            "</html>");

        } catch (SQLException se) {
            System.out.println(se.getMessage());
        }
        out.close();

    }
}