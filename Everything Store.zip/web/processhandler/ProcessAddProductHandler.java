/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package web.processhandler;

import java.io.OutputStreamWriter;

import dao.*;
import com.sun.net.httpserver.HttpHandler;


import com.sun.net.httpserver.HttpExchange;
import model.Product;
import web.util.Util;

import java.sql.SQLException;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.Map;

      //To give request and generate response 
public class ProcessAddProductHandler implements HttpHandler{
  public void handle(HttpExchange he) throws IOException {
        //To send the response
    System.out.println("ProcessAddProduct Called");
    he.sendResponseHeaders(200,0);
    BufferedWriter out = new BufferedWriter(  
        new OutputStreamWriter(he.getResponseBody() ));
    

    Map <String,String> parms = Util.requestStringToMap
    (he.getRequestURI().getQuery());
    
    System.out.println(parms);
  

    ProductDao products = new ProductDao();

    System.out.println("about to get data");
    
    
    String sku = parms.get("sku");
    String description = parms.get("description");
    String category = parms.get("category");
    int price = Integer.parseInt(parms.get("price"));

    System.out.println("about to create product");  
    Product product = new Product(sku,description,category,price);
    System.out.println("Product to Add" + product);

    try {  
    products.addProduct(product);  
      

     out.write(
      "<html>" +
      "<head> <title>Product Library</title> "+
         "<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css\" integrity=\"sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2\" crossorigin=\"anonymous\">" +
      "</head>" +
      "<body style=background-color:#C3FDB8;>" +
      "<h1 style=color:darkgreen;font-family:Luminari;> Product Added</h1>"+
      "<table class=\"table\" style=background-color:white;border:solid;border-color:MediumSeaGreen;>" +
      "<thead>" +
      "  <tr>" +
  
      "    <th>SKU</th>" +
      "    <th>Description</th>" +
      "    <th>Category</th>" +
      "    <th>Price</th>" +
    
      "  </tr>" +
      "</thead>" +
      "<tbody>");

      
        out.write(
      "  <tr>"       +
      "    <td>"+ product.getSKU() + "</td>" +
      "    <td>"+ product.getDescription() + "</td>" +
      "    <td>"+ product.getCategory() + "</td>" +
      "    <td>"+ product.getPrice() + "</td>" +
      "  </tr>" 
        );
   
      out.write(
      "</tbody>" +
      "</table>" +
      "<a href=\"/rootHandler?auth=true\">Back to List </a>"+
      "</body>" +
      "</html>");
   }catch(SQLException se){
      System.out.println(se.getMessage());
    }
  
    out.close();

}
}
