/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package web;

import com.sun.net.httpserver.HttpServer;
import web.handler.*;
import web.processhandler.*;

import java.io.IOException;
import java.net.InetSocketAddress;
/**
*A main class for WebApp
*/
public class WebApp {
    static final private int PORT = 8080;
          
    public static void start() throws IOException {

        System.out.println("Starting web App!");
        HttpServer server = HttpServer.create(new
                InetSocketAddress(PORT),0);
        server.createContext("/rootHandler", new RootHandler() );
        server.createContext("/products", new
                DisplayProductHandler() );
        server.createContext("/deleteproduct", new
                DeleteProductHandler() );
        server.createContext("/addproduct", new
                AddProductHandler());
        server.createContext("/updateproduct", new
                UpdateProductHandler());
        server.createContext("/processAddProduct", new
                ProcessAddProductHandler());
        server.createContext("/processUpdateProduct", new
                ProcessUpdateProductHandler());
        server.createContext("/customers", new
                DisplayCustomerHandler() );
        server.createContext("/addcustomer", new
                AddCustomerHandler());
        server.createContext("/deletecustomer", new
                DeleteCustomerHandler() );
        server.createContext("/processAddCustomer", new ProcessAddCustomerHandler());
        server.createContext("/updatecustomer", new
                UpdateCustomerHandler());
        server.createContext("/processUpdateCustomer", new ProcessUpdateCustomerHandler());
        server.createContext("/", new LoginHandler());
        server.createContext("/registerHandler", new RegisterHandler());
        server.createContext("/processRegisterHandler", new ProcessRegisterHandler());
        server.createContext("/searchproduct", new SearchProductHandler());
        server.createContext("/processSearchProduct", new ProcessSearchProductHandler());


        server.setExecutor(null);
        server.start();
        System.out.println("The server is listening on port " + PORT);

    }
}
