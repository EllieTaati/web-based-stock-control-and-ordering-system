/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package web.handler;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import dao.UserDao;
import web.util.Util;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.SQLException;
import java.util.Map;

     //To give request and generate response 
public class RegisterHandler  implements HttpHandler {
    public void handle(HttpExchange he) throws IOException {
         //To send the response
        System.out.println("Register Page Called");
        he.sendResponseHeaders(200,0);
        BufferedWriter out = new BufferedWriter(
                new OutputStreamWriter(he.getResponseBody() ));


        out.write(
                "<html>" +
          "<head> <title>Product Library</title> "+
                        "<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css\" integrity=\"sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2\" crossorigin=\"anonymous\">" +
                        "</head>" +
                        "<body style=background-color:#C3FDB8;>" +
                        "<div class=\"container\">"+
                        "<h1 style=color:darkgreen;font-family:Luminari;> Register </h1>"+
                        "<form method=\"get\" action=\"/processRegisterHandler\">" +
                        "<div class=\"form-group\"> "+
                        "<label for=\"ID\">username</label> " +
                        "<input type=\"text\" class=\"form-control\" name=\"username\" id=\"username\"> " +
                        "<label for=\"sku\">password</label> " +
                        "<input type=\"text\" class=\"form-control\" name=\"password\" id=\"password\"> " + "<br>" +
                        "<button type=\"submit\" class=\"btn btn-primary\">Register</button> " +
                        "</div>" +
                        "</form>" +
                    "<a href=\"/\">back to log in  </a>"+
                        "</div>" +
                        "</body>" +
                        "</html>");

        out.close();

    }
}