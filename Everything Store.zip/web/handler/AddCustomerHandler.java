/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package web.handler;

import java.io.OutputStreamWriter;

import dao.CustomerDao;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;

import java.io.BufferedWriter;
import java.io.IOException;

//To give request and generate response 
public class AddCustomerHandler implements HttpHandler{
  public void handle(HttpExchange he) throws IOException {
     //To send the response
    System.out.println("Add Customer Called");
    he.sendResponseHeaders(200,0);
    BufferedWriter out = new BufferedWriter(  
        new OutputStreamWriter(he.getResponseBody() ));
    
      CustomerDao customers = new CustomerDao();

    



     out.write(
      "<html>" +
      "<head> <title>Customer Library</title> "+
         "<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css\" integrity=\"sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2\" crossorigin=\"anonymous\">" +
      "</head>" +
      "<body style=background-color:#C3FDB8;>" +
       "<div class=\"container\">"+
      "<h1 style=color:darkgreen;font-family:Luminari;> Add Customer</h1>"+
      "<form method=\"get\" action=\"/processAddCustomer\">" +
      "<div class=\"form-group\"> "+
      
      "<label for=\"firstName\">FirstName</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"firstName\" id=\"firstName\"> " + 

      "<label for=\"secondName\">SecondName</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"secondName\" id=\"secondName\"> " + 

      "<label for=\"house\">house</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"house\" id=\"house\"> " + 

      "<label for=\"addressLine1\">addressLine1</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"addressLine1\" id=\"addressLine1\"> " + 

      "<label for=\"addressLine2\">addressLine2</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"addressLine2\" id=\"addressLine2\"> " + 

      "<label for=\"country\">country</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"country\" id=\"country\"> " + 

      "<label for=\"postCode\">postCode</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"postCode\" id=\"postCode\"> " + 

      "<label for=\"telephoneNumber\">TelephoneNumber</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"telephoneNumber\" id=\"telephoneNumber\" >" + "<br>" +
      "<button type=\"submit\" class=\"btn btn-primary\">Submit</button> " + 
      "</div>" + 
      "</form>" +
      "<a href=\"/rootHandler?auth=true\">Back to List </a>"+
      "</div>" +
      "</body>" +
      "</html>");
   
    out.close();

}
}
