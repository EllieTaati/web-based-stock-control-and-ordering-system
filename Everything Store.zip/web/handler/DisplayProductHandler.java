/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package web.handler;

import java.io.OutputStreamWriter;

import dao.ProductDao;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import model.Product;

import java.util.ArrayList;
import java.sql.SQLException;
import java.io.BufferedWriter;
import java.io.IOException;

     //To give request and generate response 
public class DisplayProductHandler implements HttpHandler{
  public void handle(HttpExchange he) throws IOException {
         //To send the response
    he.sendResponseHeaders(200,0);
    BufferedWriter out = new BufferedWriter(  
        new OutputStreamWriter(he.getResponseBody() ));

    ProductDao products = new ProductDao();
    System.out.println("All Products ...");

    try{
    ArrayList<Product> allProducts = products.getAllProducts();
      
    out.write(
      
       "<html>" +
      "<head> <title>Product Library</title> "+
        "<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css\" integrity=\"sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2\" crossorigin=\"anonymous\">" +
      "</head>" +
      "<body style=background-color:#C3FDB8;>" +
      "<div class=\"container\">" +
      "<h1 style=color:darkgreen;font-family:Luminari;> Products List!</h1>"+
      "<br>" +
      "<table class=\"table\" style=background-color:white;border:solid;border-color:MediumSeaGreen;>" +
      "<thead>" +
      "  <tr style=background-color:#F0FFFF;>" +
      "    <th>ID</th>" +
      "    <th>SKU</th>" +
      "    <th>Description</th>" +
      "    <th>Category</th>" +
      "    <th>Price</th>" +
      "    <th>Edit</th>" +
      "<th>Delete</th>" +
      "  </tr>" +
      "</thead>" +
      "<tbody>");

      for (Product p : allProducts){
        out.write(
      "  <tr>"       +
      "    <td>"+ p.getID() + "</td>" +
      "    <td>"+ p.getSKU() + "</td>" +
      "    <td>"+ p.getDescription() + "</td>" +
      "    <td>"+ p.getCategory() + "</td>" +
      "    <td>"+ p.getPrice() + "</td>" +
      "    <td> <a href=\"/updateproduct?id=" + p.getID() + "\"> edit </a> </td>" +  
      "    <td> <a href=\"/deleteproduct?id=" + p.getID() + "\"> delete </a> </td>" +  
      "  </tr>" 
        );
      }
      out.write(
      "</tbody>" +
      "</table>" +
       "<a href=\"/rootHandler?auth=true\">Back to List </a>"+
       "</div>" +
             
      "</body>" +
      "</html>");
     }catch(SQLException se){
      System.out.println(se.getMessage());
    }
    out.close();
  }
}
