/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package web.handler;

import java.io.OutputStreamWriter;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import dao.UserDao;
import web.util.Util;

import java.io.BufferedWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

   //To give request and generate response 
public class RootHandler implements HttpHandler{
  public void handle(HttpExchange he) throws IOException {

        // Add the mouse tracking script here
        String mouseTrackingScript = "<script type=\"text/javascript\">\n"
            + "  window._mfq = window._mfq || [];\n"
            + "  (function() {\n"
            + "    var mf = document.createElement(\"script\");\n"
            + "    mf.type = \"text/javascript\"; mf.defer = true;\n"
            + "    mf.src = \"//cdn.mouseflow.com/projects/52b93edc-0a21-4353-91d9-f9af1b85b659.js\";\n"
            + "    document.getElementsByTagName(\"head\")[0].appendChild(mf);\n"
            + "  })();\n"
            + "</script>";
    
    //To send the response
    he.sendResponseHeaders(200,0);
    System.out.println("start root handler");
    Map<String,String> parms = Util.requestStringToMap
            (he.getRequestURI().getQuery());
    System.out.println(parms);
    UserDao userDao = new UserDao();
    System.out.println("about to get data");
    String username = parms.get("username");
    String password = parms.get("password");
    String auth = parms.get("auth");
    boolean authorized= false;
    try {
      authorized =  auth!=null?true:userDao.login(username, password);
    } catch (SQLException e) {
      throw new RuntimeException(e);
    }

    BufferedWriter out = new BufferedWriter(  
        new OutputStreamWriter(he.getResponseBody() ));

    // Output the mouse tracking script to the response
        out.write(mouseTrackingScript);

    if(!authorized) {
      out.write(
              "<html>" +
     "<head> <title>Product Library</title> "+ "<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css\" integrity=\"sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2\" crossorigin=\"anonymous\">" +
                      "</head>" +
                      "<body>" +
                      "<div class=\"container\">" +
                      "<h1><center>User or password is not correct</center></h1>" +
                      "<a href=\"/\">Back to Login </a>"+
                      "</div>" +
                      "</body>" +
                      "</html>");
    } else {
      out.write(
              "<html>" +
              "<head> <title>Product Library</title> " +
              "<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css\" integrity=\"sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2\" crossorigin=\"anonymous\">" +
               "</head>" +
               "<body style=background-color:#C3FDB8;>" +
               "<div class=\"container\">" +
"<h1 style= color:#FDBD01;background-color:MediumSeaGreen;border:solid;border-color:darkgreen;font-family:copperplate;font-size:300%;><center> The Everything Store </center></h1>" +
    "<h2 style=color:darkgreen;background-color:#F0FFFF;font-family:Luminari;border-size:2px;border:solid;border-color:MediumSeaGreen;>&nbsp;Menu</h2>" +
        "<ul style=background-color:#F0FFFF;border:solid;border-color:MediumSeaGreen;>"+
        "<br>" +
 "<li class=\"menuitem\" onclick=\"reStyle(0)\">"+
 "<a href=\"/products\">&nbsp;&nbsp;Display Products</a> " +
                      "<br>" +
   "<li class=\"menuitem\" onclick=\"reStyle(0)\">"+
   "<a href=\"/addproduct\">&nbsp;&nbsp;Add Product</a> " +
                      "<br>" +
   "<li class=\"menuitem\" onclick=\"reStyle(0)\">"+
"<a href=\"/searchproduct\">&nbsp;&nbsp;Search Product By Description</a> " +
                      "<br>" +
  "<li class=\"menuitem\" onclick=\"reStyle(0)\">"+
   "<a href=\"/customers\">&nbsp;&nbsp;Display Customers</a> " +
                      "<br>" +
   "<li class=\"menuitem\" onclick=\"reStyle(0)\">"+
"<a href=\"/addcustomer\">&nbsp;&nbsp;Add Customer</a> " + 
                     "<br>" +
                      "<br>" +
       "<a href=\"/\">&nbsp;&nbsp;Log out </a>"+
        "<br>" + "<br>" +
        "<img src=\"https://image.delti.com/simg/landingpages/tyres.jpg\" alt=\"Tyre\" width=\"445\" height=\"300\" float=\"right\">"+
         "<br>" +"<br>" +
        "</ul>"+
                      "</div>" +
                      "</body>" +
                      "</html>");

    }
    out.close();

  }
}