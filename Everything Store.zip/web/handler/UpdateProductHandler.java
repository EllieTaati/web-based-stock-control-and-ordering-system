/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package web.handler;

import java.io.OutputStreamWriter;

import dao.ProductDao;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import model.Product;
import web.util.Util;

import java.sql.SQLException;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.Map;

      //To give request and generate response 
public class UpdateProductHandler implements HttpHandler{
  public void handle(HttpExchange he) throws IOException {
         //To send the response
    System.out.println("Update Product Handler Called");
    he.sendResponseHeaders(200,0);
    BufferedWriter out = new BufferedWriter(  
        new OutputStreamWriter(he.getResponseBody() ));

    Map <String,String> parms = Util.requestStringToMap
    (he.getRequestURI().getQuery());


    int ID = Integer.parseInt(parms.get("id"));

    System.out.println("id is"+ ID);
    try {
      ProductDao productDao = new ProductDao();
      Product product = productDao.getProduct(ID);
      System.out.println("product is "+ product);
      System.out.println("description in first is:"+ product.getDescription());

    



     out.write(
      "<html>" +
      "<head> <title>Product Library</title> "+
         "<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css\" integrity=\"sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2\" crossorigin=\"anonymous\">" +
      "</head>" +
      "<body style=background-color:#C3FDB8;>" +
       "<div class=\"container\">"+
      "<h1 style=color:darkgreen;font-family:Luminari;> Update Product</h1>"+
      "<form method=\"get\" action=\"/processUpdateProduct\">" +
      "<div class=\"form-group\"> "+

      "<input type=\"hidden\" class=\"form-control\" name=\"id\" id=\"id\"  value=\""+product.getID()+ "\"  > " +
       
      "<label for=\"sku\">SKU</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"sku\" id=\"sku\" value=\""+product.getSKU()+ "\" > " + 

      "<label for=\"description\">Description</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"description\" id=\"description\" value=\""+product.getDescription()+"\" > " + 

      "<label for=\"category\">Category</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"category\" id=\"category\" value=\""+product.getCategory()+"\"> " + 

      "<label for=\"price\">Price</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"price\" id=\"price\" value=\""+product.getPrice()+"\" >" + "<br>" +
      "<button type=\"submit\" class=\"btn btn-primary\">Submit</button> " + 
      "</div>" + 
      "</form>" +
      "<a href=\"/rootHandler?auth=true\">Back to List </a>"+
      "</div>" +
      "</body>" +
      "</html>");

     }catch(SQLException se){
      System.out.println(se.getMessage());
    }
    out.close();

}
}
