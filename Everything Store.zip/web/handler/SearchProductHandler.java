/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package web.handler;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import dao.CustomerDao;
import model.Customer;
import web.util.Util;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.SQLException;
import java.util.Map;

      //To give request and generate response 
public class SearchProductHandler implements HttpHandler {
        //To send the response
    public void handle(HttpExchange he) throws IOException {

        System.out.println("Search Product Handler Called");
        he.sendResponseHeaders(200, 0);
        BufferedWriter out = new BufferedWriter(
                new OutputStreamWriter(he.getResponseBody()));

        out.write(
                "<html>" +
            "<head> <title>Product Library</title> " +
                        "<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css\" integrity=\"sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2\" crossorigin=\"anonymous\">" +
                        "</head>" +
                        "<body style=background-color:#C3FDB8;>" +
                        "<div class=\"container\">" +
    "<h1 style=color:darkgreen;font-family:Luminari;> Search Product By Description</h1>" +
                        "<form method=\"get\" action=\"/processSearchProduct\">" +
                        "<div class=\"form-group\"> " +
                        "<h2> Please Enter description</h2>" +
                        "<input type=\"text\" class=\"form-control\" name=\"searchDescription\" id=\"searchDescription\"  >" + "<br>" +
                        "<button type=\"submit\" class=\"btn btn-primary\">Search</button> " +
                        "</div>" +
                        "</form>" +
             "<a href=\"/rootHandler?auth=true\">Back to List </a>" +
                        "</div>" +
                        "</body>" +
                        "</html>");


        out.close();

    }
}
