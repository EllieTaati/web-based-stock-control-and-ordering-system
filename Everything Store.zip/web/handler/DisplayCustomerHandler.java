/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package web.handler;

import java.io.OutputStreamWriter;

import dao.CustomerDao;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import model.Customer;

import java.util.ArrayList;
import java.sql.SQLException;
import java.io.BufferedWriter;
import java.io.IOException;

      //To give request and generate response 
public class DisplayCustomerHandler implements HttpHandler{
  public void handle(HttpExchange he) throws IOException {       //To send the response    
    he.sendResponseHeaders(200,0);
    BufferedWriter out = new BufferedWriter(  
        new OutputStreamWriter(he.getResponseBody() ));
    
   CustomerDao customers = new CustomerDao();
    try{
    ArrayList<Customer> allCustomers = customers.getAllCustomer();
   
    out.write(
      "<html>" +
      "<head> <title>Customer Library</title> "+
      "<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css\" integrity=\"sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2\" crossorigin=\"anonymous\">" +
      "</head>" +
       "<body style=background-color:#C3FDB8;>" +
      "<div class=\"container\">" +
      "<h1 style=color:darkgreen;font-family:Luminari;> Customers List!</h1>"+
      "<br>" +
      "<table class=\"table\" style=background-color:white;border:solid;border-color:MediumSeaGreen;>" +
      "<thead>" +
     "  <tr style=background-color:#F0FFFF;>" +
      "    <th>CustomerID</th>" +
      "    <th>FirstName</th>" +
      "    <th>SecondName</th>" +
      "    <th>model.Address</th>" +
      "    <th>TelephoneNumber</th>" +
      "    <th>Update</th>" +
      "    <th>Delete</th>" +
      "  </tr>" +
      "</thead>" +
      "<tbody>");

      for (Customer c : allCustomers){
        out.write(
      "  <tr>"       +
      "    <td>"+ c.getCustomerID() + "</td>" +
      "    <td>"+ c.getFirstName() + "</td>" +
      "    <td>"+ c.getSecondName() + "</td>" +
      "    <td>"+ c.getAddressId() + "</td>" +
      "    <td>"+ c.getTelephoneNumber() + "</td>" +
      "<td> <a href=\"/updatecustomer?customerId=" + c.getCustomerID() + "\"> update </a> </td>" +  
      "    <td> <a href=\"/deletecustomer?customerId=" + c.getCustomerID() + "\"> delete </a> </td>" +  
      "  </tr>" 
        );
      }
      out.write(
      "</tbody>" +
      "</table>" +
              "<a href=\"/rootHandler?auth=true\">Back to List </a>"+
              "</div>" +
             
      "</body>" +
      "</html>"
      );
     }catch(SQLException se){
      System.out.println(se.getMessage());
    }
    out.close();
  }
}