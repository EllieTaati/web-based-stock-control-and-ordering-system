/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package web.handler;

import java.io.OutputStreamWriter;

import dao.CustomerDao;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import model.Customer;
import web.util.Util;

import java.sql.SQLException;
import java.io.BufferedWriter;
import java.io.IOException;
import java.util.Map;

      //To give request and generate response 
public class UpdateCustomerHandler implements HttpHandler{
  public void handle(HttpExchange he) throws IOException {          //To send the response
    System.out.println("Update Customer Handler Called");
    he.sendResponseHeaders(200,0);
    BufferedWriter out = new BufferedWriter(  
        new OutputStreamWriter(he.getResponseBody() ));

    Map <String,String> parms = Util.requestStringToMap
    (he.getRequestURI().getQuery());


    int ID = Integer.parseInt(parms.get("customerId"));

    System.out.println("id is"+ ID);
    try {
      CustomerDao customerDao = new CustomerDao();
      Customer customer = customerDao.getCustomer(ID);
      System.out.println("customer is "+ customer);
   
    



     out.write(
      "<html>" +
      "<head> <title>Customer Library</title> "+
         "<link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css\" integrity=\"sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2\" crossorigin=\"anonymous\">" +
      "</head>" +
     "<body style=background-color:#C3FDB8;>" +
       "<div class=\"container\">"+
      "<h1 style=color:darkgreen;font-family:Luminari;> Update Customer</h1>"+
      "<form method=\"get\" action=\"/processUpdateCustomer\">" +
      "<div class=\"form-group\"> "+
      "<input type=\"hidden\" class=\"form-control\" name=\"customerID\" id=\"customerID\"  value=\""+customer.getCustomerID()+ "\"  > " +
       
      "<label for=\"firstName\">FirstName</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"firstName\" id=\"firstName\" value=\""+customer.getFirstName()+ "\" > " + 

      "<label for=\"secondName\">SecondName</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"secondName\" id=\"secondName\" value=\""+customer.getSecondName()+"\" > " + 

      "<label for=\"house\">house</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"house\" id=\"house\" value=\""+customer.getAddressId().getHouse()+"\"> " + 

      "<label for=\"addressLine1\">addressLine1</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"addressLine1\" id=\"addressLine1\" value=\""+customer.getAddressId().getAddressLine1()+"\" > " + 

      "<label for=\"addressLine2\">addressLine2</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"addressLine2\" id=\"addressLine2\" value=\""+customer.getAddressId().getAddressLine2()+"\" > " + 

      "<label for=\"country\">country</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"country\" id=\"country\" value=\""+customer.getAddressId().getCountry()+"\" > " + 

      "<label for=\"postCode\">postCode</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"postCode\" id=\"postCode\"value=\""+customer.getAddressId().getPostCode()+"\" > " + 
      "<label for=\"telephoneNumber\">TelephoneNumber</label> " + 
      "<input type=\"text\" class=\"form-control\" name=\"telephoneNumber\" id=\"telephoneNumber\" value=\""+customer.getTelephoneNumber()+"\" >" + "<br>" +
      "<button type=\"submit\" class=\"btn btn-primary\">Update</button> " + 
      "</div>" + 
      "</form>" +
      "<a href=\"/rootHandler?auth=true\">Back to List </a>"+
      "</div>" +
      "</body>" +
      "</html>");

     }catch(SQLException se){
      System.out.println(se.getMessage());
    }
    out.close();

}
}
