/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package model;
/**
*A simple class of Address
*/
public class Address {
  
  /**
  *@param addressId an integer to browse for address
  *@param house is a string for house in address 
  *@param addressLine1 is a string to specify the first line of address
  *@param addressLine2 is a string to specify the second line of address
  *@param country is to specify the country in address
  *@param postCode is a string to specify the postcode in address
  */
  
  private int addressId; 
	private String house;
	private String addressLine1;
	private String addressLine2;
	private String country;
  private String postCode;
	
	public Address(int addressId,String house, String addressLine1, String addressLine2, String country, String postCode) {
	/**
*The constructor that includes getting addressId
* To initialise instance variables
*/
    
		this.house = house;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.country = country;
    this.postCode = postCode;
    this.addressId = addressId;
	}
/**
*The constructor without getting addressId to autogenerate id
*/
	public Address(String house, String addressLine1, String addressLine2, String country, String postCode) {

		this.house = house;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.country = country;
		this.postCode = postCode;
	}
  /**
  *@return the addressId in address
  */

  public int getAddressId() {
		return this.addressId;
	}
   /**
	 * @param addressId sets the id for each address 
	 */
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
  /**
  *@return the house in address
  */
	public String getHouse() {
		return this.house;
	}
  /**
	 * @param house sets the house detail for each address 
	 */
	public void setHouse(String house) {
		this.house = house;
	}
  /**
  *@return the first line of the address in address
  */
	public String getAddressLine1() {
		return this.addressLine1;
	}
   /**
	 * @param addressLine1 sets the first line of address 
	 */
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
  /**
  *@return the second line of the address in address
  */
	public String getAddressLine2() {
		return this.addressLine2;
	}
   /**
	 * @param addressLine2 sets the second line of address 
	 */
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
    /**
  *@return the name of country in address
  */
	public String getCountry() {
		return this.country;
	}
  /**
	 * @param country sets the country name in  address 
	 */
	public void setCountry(String country) {
		this.country= country;
	}
   /**
  *@return the postcode detail in address
  */

  public String getPostCode() {
		return this.postCode;
	}
  /**
	 * @param postCode sets the postcode in  address 
	 */
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	@Override
	public String toString() {
	return "House=" + this.house + ", AddressLine1=" + 
  this.addressLine1 + ", AddressLine2=" + this.addressLine2 + ", Country=" + this.country + ",PostCode=" + this.postCode;
	}
	
}
