/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package model;

import model.Address;
/**
*A simple class of customers
*/
public class Customer {

  /**
  *@param customerID an integer to browse for customers
  *@param firstName is a string for each customer's first name 
  *@param secondName is a string for each customer's second name 
  *@param addressId to refer the customer's address from "Adress Class"
  *@param telephoneNumber a string to specify the telephone number for each customer
  */
	private int customerID;
	private String firstName;
	private String secondName;
	private Address addressId;
  	private String telephoneNumber;
	
	
	public Customer(int customerID, String firstName, String secondName, Address addressId, String telephoneNumber) {
		/**
    *The constructor that includes getting customerID
    *To initialise instance variables
    */
    
		this.customerID = customerID;
		this.firstName = firstName;
		this.secondName = secondName;
		this.addressId = addressId;
    this.telephoneNumber = telephoneNumber;
	}

	public Customer( String firstName, String secondName, Address addressId, String telephoneNumber) {
/**
*The constructor without getting customerID to autogenerate id
*/
		this.firstName = firstName;
		this.secondName = secondName;
		this.addressId = addressId;
		this.telephoneNumber = telephoneNumber;
	}
  /**
  *@return the customerID in customer
  */
	public int getCustomerID() {
		return this.customerID;
	}
  /**
	 * @param customerID sets the id for each customer 
	 */
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
  /**
  *@return the first name of each customer in customer
  */
	public String getFirstName() {
		return this.firstName;
	}
   /**
	 * @param firstName sets the first name for each customer 
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
  /**
  *@return the second name of each customer in customer
  */
	public String getSecondName() {
		return this.secondName;
	}
  /**
	 * @param secondName sets the second name for each customer 
	 */
	public void setSecondName(String secondName) {
		this.secondName = secondName;
	}
    /**
  *@return the address  of each customer 
  */
	public Address getAddressId() {
		return this.addressId;
	}
  /**
	 * @param addressId sets the address for each customer throw the Address class
	 */
	public void setAddressId(Address addressId) {
		this.addressId = addressId;
	}
 /**
  *@return the telephone number of each customer  
  */
  public String getTelephoneNumber() {
		return this.telephoneNumber;
	}
  /**
	 * @param telephoneNumber sets the telephone number for each customer 
	 */
	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}

	@Override
	public String toString() {
		return "Customer [CustomerID=" + this.customerID + ", FirstName=" + this.firstName + ", SecondName=" + this.secondName + ", AddressId=" + this.addressId + ",TelephoneNumber=" + this.telephoneNumber + "]";
	}
	
}
