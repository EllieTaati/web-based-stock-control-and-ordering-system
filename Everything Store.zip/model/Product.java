/** 
*@author Elham Taati Shaldehi MMU ID : 22557023
**/

package model;
/**
*A simple class of products
*/

public class Product {

  /**
  *@param id an integer to browse for products
  *@param SKU (stock keeping unit) a unique code for each product 
  *@param description a string to describe each product
  *@param category a string to browse the category for each product 
  *@param price an integer to specify the price for each product
  */
	
	private int id;
	private String SKU;
	private String description;
	private String category;
  private int price;

   /**
    *The constructor that includes getting ID
    * To initialise instance variables
    */
	public Product(int ID, String SKU, String description, String category, int price) {
	
		this.id = ID;
		this.SKU = SKU;
		this.description = description;
		this.category = category;
    	this.price = price;
	}
   /**
    *The Constructor without getting ID to autogenerate id
    */
	public Product(String SKU, String description, String category, int price) {
		this.SKU = SKU;
		this.description = description;
		this.category = category;
		this.price = price;
	}
/**
  *@return the id of product
  */
	public int getID() {
		return this.id;
	}
  	/**
	 * @param id sets the id for each product 
	 */
	public void setID(int id) {
		this.id = id;
	}
  /**
  *@return the unique SKU  of each product
  */
	public String getSKU() {
		return this.SKU;
	}
  /**
	 * @param SKU sets the SKU for each product 
	 */
	public void setSKU(String SKU) {
		this.SKU = SKU;
	}
  /**
	 * @return the description that each product has
	 */
	public String getDescription() {
		return this.description;
	}
  /**
	 * @param description sets the description that   each product has
	 */
	public void setDescription(String description) {
		this.description = description;
	}
  /**
	 * @return the category for each product 
	 */
  
	public String getCategory() {
		return this.category;
	}
    /**
	 * @param category sets category type for each product
	 */
	public void setCategory(String category) {
		this.category = category;
	}
/**
	 * @return the amount price for each product 
	 */
  public int getPrice() {
		return this.price;
	}
  
    /**
	 * @param price sets the amount of price for each product
	 */
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [ID=" + this.id + ", SKU=" + this.SKU + ", Description=" + this.description + ", Category=" + this.category + ",Price=" + this.price + "]";
	}
	
}
